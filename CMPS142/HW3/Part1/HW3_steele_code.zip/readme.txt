run with python 2.7
python hw3_1.py

Requires files in folder called FilesForHW3Part1 in same location as .py file.